package ru.stqa.selenium.selenium;

public class fluentwait
{
    public static void main(String[] args) {

    }
}
