package ru.stqa.selenium.programs;

public class methodsdemo2 {
    public String getUserData(){
        System.out.println("hello world");
        return "jaime";

    }
}
