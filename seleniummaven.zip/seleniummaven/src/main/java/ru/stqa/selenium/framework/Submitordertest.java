package ru.stqa.selenium.framework;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;

public class Submitordertest {
    public static void main(String[] args) throws InterruptedException {



        WebDriver driver = new ChromeDriver();
        String productName= "ZARA COAT 3";
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        Landingpage Lamdingpage = new Landingpage(driver);
        Lamdingpage.goURl();
        Productcataloge productcataloge=  Lamdingpage.loginAplication("jaimecbescuela@hotmail.com","Secretariojaime99*");
        List<WebElement> productss=  productcataloge.getopcionesList();
        productcataloge.addProductTOCART(productName);
        CartPage cartPage =productcataloge.goToCartPage();

        Boolean match = cartPage.VerifyProductDisplay(productName);
        Assert.assertTrue(match);
        CheckoutPage checkoutPage=   cartPage.goToCheckout();
        checkoutPage.setSelectCountry("Mexico");
        ConfirmationPage confirmationPage= checkoutPage.submitorder();
        String confirmmessage = confirmationPage.verifyconfirmationmessage();

        Assert.assertTrue(confirmmessage.equalsIgnoreCase("THANKYOU FOR THE ORDER"));
        driver.close();









    }
}
